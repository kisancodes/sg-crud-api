// Set up environment variables for testing
process.env.DYNAMODB_TABLE = 'test-table';
process.env.REGION = 'us-east-1';